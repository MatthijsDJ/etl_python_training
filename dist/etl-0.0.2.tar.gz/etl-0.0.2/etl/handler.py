def read():
    print("Reading data.")

def transform():
    print("Transforming data")

def process():
    print("Processing data")
    print("Filtering data")

def write():
    print("Writing results")

def run():
    read()
    transform()
    process()
    write()

if __name__ == "__main__":
    run()