#from .handler import run
import etl.handler

if  __name__ == '__main__':
    etl.handler.run()