from setuptools import (setup,
                        find_packages)


setup(
    name='etl',
    version='0.0.2',
    url='https://example.org',
    author='Matthijs',
    author_email='m.d.jong@gmail.com',
    packages=['etl']
)                